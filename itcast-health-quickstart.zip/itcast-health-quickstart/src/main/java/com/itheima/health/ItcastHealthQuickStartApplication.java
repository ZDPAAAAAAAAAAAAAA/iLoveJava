package com.itheima.health;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItcastHealthQuickStartApplication {

    public static void main(String[] args) {
        SpringApplication.run(ItcastHealthQuickStartApplication.class, args);
    }
}
