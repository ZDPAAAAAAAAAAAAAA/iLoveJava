package com.itheima.health.controller.backend;

import com.itheima.health.constant.MessageConstant;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.entity.Result;
import com.itheima.health.pojo.CheckGroup;
import com.itheima.health.service.CheckGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/checkgroup")
public class CheckGroupController {
@Resource
    private CheckGroupService checkGroupService;
    @RequestMapping("/add.do")
    public Result add(@RequestBody CheckGroup checkGroup, Integer[] checkItemIds){
        //1 调用业务检查组
        checkGroupService.add(checkGroup,checkItemIds);
        //2 统一响应结果
        return new Result(true,MessageConstant.ADD_CHECKGROUP_SUCCESS);
    }

    @RequestMapping("/findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
// 1.调用业务层分页查询
        PageResult pageResult = checkGroupService.findPage(queryPageBean);
// 2.响应 PageResult
        return pageResult;
    }

    /**
     * * 根据id查询检查组
* @param id 检查组id
* @return 统一响应结果,包含检查组数据
*/
    @RequestMapping("/findById.do")
    public Result findById(Integer id) {
        CheckGroup checkGroup = checkGroupService.findById(id);
        return new Result(true, MessageConstant.QUERY_CHECKGROUP_SUCCESS,
                checkGroup);
    }
    /**
     * 根据检查组合id查询对应的所有检查项id
     * @param checkGroupId
     * @return 统一响应结果, 包含所有检查项id
     */
    @RequestMapping("/findCheckItemIdsByCheckGroupId.do")
    public Result findCheckItemIdsByCheckGroupId(Integer checkGroupId) {
// 1.调用业务层根据检查组合id查询对应的所有检查项id
        List<Integer> checkItemIds =
                checkGroupService.findCheckItemIdsByCheckGroupId(checkGroupId);
// 2.响应统一结果Result, 包含所有检查项id
        return new Result(true, MessageConstant.QUERY_CHECKITEM_SUCCESS,
                checkItemIds);
    }

    /**
     * 编辑检查项
     * @param checkGroup 检查组数据
     * @return 统一响应结果
     */
    @RequestMapping("/edit.do")
    public Result edit(@RequestBody CheckGroup checkGroup, Integer[] checkItemIds) {
// 1.调用业务层编辑检查组
        checkGroupService.edit(checkGroup, checkItemIds);
// 2.响应统一结果Result
        return new Result(true, MessageConstant.EDIT_CHECKGROUP_SUCCESS);
    }

    /**
     * 查询所有的检查组
     * @return
     */
    @RequestMapping("/findAll.do")
    public Result findAll() {
// 1.调用业务层查询所有检查组
        List<CheckGroup> checkGroups = checkGroupService.findAll();
// 2.响应统一结果,包含检查组数据
        return new Result(true, MessageConstant.QUERY_CHECKGROUP_SUCCESS,
                checkGroups);
    }


}
