package com.itheima.health.controller.backend;

import com.itheima.health.constant.MessageConstant;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.entity.Result;
import com.itheima.health.pojo.CheckItem;
import com.itheima.health.service.CheckItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("checkitem")
public class CheckItemController {
    @Autowired
    CheckItemService checkItemService;

    @RequestMapping("add.do")
    public Result add(@RequestBody CheckItem checkItem) {
        checkItemService.add(checkItem);
        return null;
    }

    /**
     * 检查项分页查询
     *
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    @RequestMapping("findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
// 1.调用业务层分页查询
        PageResult pageResult = checkItemService.findPage(queryPageBean);
// 2.响应 PageResult
        return pageResult;
    }


        /**
         * 删除检查项
         * @param id 要删除的检查项id
         * @return 统一响应结果
         */
        @RequestMapping("delete.do")
        public Result delect (Integer id){
            // 1.调用业务层分页查询
            boolean delete = checkItemService.delete(id);
            // 2.响应统一结果Result
            String message = delete ? MessageConstant.DELETE_CHECKITEM_SUCCESS :
                    MessageConstant.DELETE_CHECKITEM_FAIL;
            return new Result(delete, message);
//            checkItemService.delete(id);
//            return  null;

        }


    /**
     * 根据id查询检查项
     * @param id 检查项id
     * @return 统一响应结果,包含检查项数据
    6.2.2 业务层接口
    在CheckItemService接口中扩展编辑方法
    6.2.3 业务层实现类
    在CheckItemServiceImpl实现类中实现编辑方法
     */
    @RequestMapping("/findById.do")
    public Result findById(Integer id) {
// 1.调用业务层根据id查询检查项
        CheckItem checkItem = checkItemService.findById(id);
// 2.响应统一结果Result,包含检查项数据
        return new Result(true, MessageConstant.QUERY_CHECKITEM_SUCCESS, checkItem);
    }
    /**
     * 编辑检查项
     * @param checkItem 检查项数据
     * @return 统一响应结果
     */

    @RequestMapping("/edit.do")
    public Result edit(@RequestBody CheckItem checkItem) {
// 1.调用业务层编辑检查项
        checkItemService.edit(checkItem);
// 2.响应统一结果Result
        return new Result(true, MessageConstant.EDIT_CHECKITEM_SUCCESS);
    }

    /**
     * 检查组管理
     *  查询所有信息
     *
     */
    @RequestMapping("/findAll.do")
    public Result findAll() {
// 1.调用业务层查询所有检查项
        List<CheckItem> checkItems = checkItemService.findAll();
// 2.响应Result
        return new Result(true, MessageConstant.QUERY_CHECKITEM_SUCCESS,
                checkItems);
    }






}
