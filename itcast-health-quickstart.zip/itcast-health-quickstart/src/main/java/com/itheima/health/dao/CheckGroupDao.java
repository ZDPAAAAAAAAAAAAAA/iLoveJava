package com.itheima.health.dao;

import com.itheima.health.pojo.CheckGroup;
import org.apache.ibatis.annotations.*;
import com.github.pagehelper.Page;

import java.util.List;

@Mapper
public interface CheckGroupDao {

    @Insert("insert into t_checkgroup values (null, #{code}, #{name}, #{helpCode}, #{sex}, #{remark}, #{attention});")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void add(CheckGroup checkGroup);

    /**
     * 在中间表中指定检查组中包含的检查项
     *
     */
    @Insert("insert into t_checkgroup_checkitem values (#{checkGroupId}, #{checkItemId});")
    void setCheckGroupAndCheckItem(Integer checkGroupId, Integer checkItemId);

    /**
     * 检查组分页查询
     * @param queryString 查询关键字
     * @return 分页查询结果
     */
    Page<CheckGroup> findPage(String queryString);

    /**
     * 根据id查询检查组
     * @param id 检查组id
     * @return 检查组数据
     */
    @Select("select * from t_checkgroup where id = #{id};")
    CheckGroup findById(Integer id);
/**
 * 根据检查组id查询对应的所有检查项id
 * @param checkGroupId 检查组id
 * @return 检查组合的所有检查项id
 */
    @Select("select checkitem_id from t_checkgroup_checkitem where checkgroup_id = #{checkGroupId};")
    List<Integer> findCheckItemIdsByCheckGroupId(Integer checkGroupId);
    /**
     * 编辑检查项
     * @param checkGroup 检查组数据
     */
    void edit(CheckGroup checkGroup);
/**
 * 根据检查组id删除中间表数据（清理原有关联关系）
 * @param id 检查组id
 */
    @Delete("delete from t_checkgroup_checkitem where checkgroup_id = #{checkgroup_id};")
            void deleteAssociation(Integer id);

    /**
     * 查询所有检查组
     * @return 所有检查组数据
     */
    @Select("select * from t_checkgroup;")
    List<CheckGroup> findAll();



}
