package com.itheima.health.dao;

import com.github.pagehelper.Page;
import com.itheima.health.pojo.CheckItem;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CheckItemDao {
    @Insert("insert into t_checkitem values(null, #{code}, #{name}, #{sex}, #" +
            "{age}, #{price}, #{type}, #{remark}, #{attention});")
    public void add(CheckItem checkItem);

    /**
     * 检查项分页查询
     * @param queryString 查询关键字
     * @return 分页查询的数据
     */
    public Page<CheckItem> findPage(String queryString);


    /**
     * 查询当前检查项是否和检查组关联
     * @param id 检查项id
     * @return 检查项被引用的数量
     */
    @Select("select count(*) from t_checkgroup_checkitem where checkitem_id = #{id};")
            long findCountByCheckItemId(Integer id);
    /**
     * 删除检查项
     * @param id 检查项id
     */
    @Delete("delete from t_checkitem where id = #{id};")
    void deleteById(Integer id);

    @Select("select * from t_checkitem where id = #{id};")
    CheckItem findById(Integer id);

    void edit(CheckItem checkItem);

    /**
     *
     * 查询所有检查项
     *
     */

    @Select("select  * from t_checkitem;")
    List<CheckItem> findAll();

}
