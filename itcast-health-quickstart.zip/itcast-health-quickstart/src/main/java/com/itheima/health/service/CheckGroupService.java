package com.itheima.health.service;

import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.CheckGroup;

import java.util.List;

public interface CheckGroupService {
    /**
     * 新增检查组
     * @param checkGroup    检查组信息
     * @param checkItemIds  检查组的检查项的信息
     */
    void add(CheckGroup checkGroup, Integer[] checkItemIds);

    /**
     * 检查组分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    PageResult findPage(QueryPageBean queryPageBean);


    /**
     * 根据id查询检查组
     * @param id 检查组id
     * @return 检查组数据
     */
    CheckGroup findById(Integer id);

    /**
     * 根据检查组id查询对应的所有检查项id
     * @param checkGroupId 检查组id
     * @return 检查组合的所有检查项id
     */
    List<Integer> findCheckItemIdsByCheckGroupId(Integer checkGroupId);

    /**
            * 编辑检查项
*
        * @param checkGroup 检查组数据
* @param checkItemIds
*/
    void edit(CheckGroup checkGroup, Integer[] checkItemIds);


    /**
     * 查询所有检查组
     * @return 所有检查组数据
     */
    List<CheckGroup> findAll();





}
