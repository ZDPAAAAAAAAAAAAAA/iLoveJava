package com.itheima.health.service;

import com.itheima.health.dao.CheckItemDao;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.entity.Result;
import com.itheima.health.pojo.CheckItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


public interface CheckItemService {

    public void add(CheckItem checkItem);

    /**
     * 检查项分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    PageResult findPage(QueryPageBean queryPageBean);

    /**
     * 删除检查项
     * @param id 要删除的检查项id
     * @return 统一响应结果
     */
    boolean delete(Integer id);

    /**
     * 根据id查询检查项
     * @param id 检查项id
     * @return 检查项数据
     */
    CheckItem findById(Integer id);
    /**
     * 编辑检查项
     * @param checkItem 检查项数据
     */
    void edit(CheckItem checkItem);

    /**
     * 查询所有检查项
     * @return 所有检查项数据
     */
    List<CheckItem> findAll();



}
