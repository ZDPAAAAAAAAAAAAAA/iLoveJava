package com.itheima.health.service.Impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.health.dao.CheckGroupDao;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.CheckGroup;
import com.itheima.health.service.CheckGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CheckGroupServiceImpl implements CheckGroupService {
    @Autowired
 private CheckGroupDao checkGroupDao;
    @Override
    public void add(CheckGroup checkGroup, Integer[] checkItemIds) {
        //新增检查组信息
        checkGroupDao.add(checkGroup);

        //在中间表中指定检查组中包含的检查项
        setCheckGroupAndCheckItem(checkGroup.getId(),checkItemIds);

    }


    /**
     * 在中间表插入检查组id和检查项的id,形成关联
     * @param checkGroupId 检查组id
     * @param checkItemIds 检查组对应的所有检查项
     */
    public void setCheckGroupAndCheckItem(Integer checkGroupId,Integer[] checkItemIds){
        if (checkItemIds !=null && checkItemIds.length>0){
            for (Integer checkItemId : checkItemIds){
                //调用dao层往数据库中新增一个检查组的id和检查项的id
                checkGroupDao.setCheckGroupAndCheckItem(checkGroupId,checkItemId);
            }
        }
    }

    /**
     * 检查组分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    @Override
    public PageResult findPage(QueryPageBean queryPageBean) {
// 1.使用分页插件开始分页
        PageHelper.startPage(queryPageBean.getCurrentPage(),
                queryPageBean.getPageSize());
// 2.调用DAO分页查询
        Page<CheckGroup> page =
                checkGroupDao.findPage(queryPageBean.getQueryString());
        return new PageResult(page.getTotal(), page.getResult());
    }
    /**
     * 根据id查询检查组
     * @param id 检查组id
     * @return 检查组数据
     */
    @Override
    public CheckGroup findById(Integer id) {
// 1.调用DAO根据id查询检查组
        CheckGroup checkGroup = checkGroupDao.findById(id);
// 2.返回检查组对象
        return checkGroup;
    }
    /**
     * 根据检查组id查询对应的所有检查项id
     * @param checkGroupId 检查组id
     * @return 检查组合的所有检查项id
     */
    @Override
    public List<Integer> findCheckItemIdsByCheckGroupId(Integer checkGroupId) {
// 1.调用DAO根据检查组id查询对应的所有检查项id
        List<Integer> checkItemIds =
                checkGroupDao.findCheckItemIdsByCheckGroupId(checkGroupId);
// 2.返回检查组合的所有检查项id
        return checkItemIds;
    }
/**
 * 编辑检查项
 *
 * @param checkGroup 检查组数据
 * @param checkItemIds
 */
    @Override
    public void edit(CheckGroup checkGroup, Integer[] checkItemIds) {
// 1.调用DAO 编辑检查组
        checkGroupDao.edit(checkGroup);
// 2.调用DAO 根据检查组id删除中间表数据（清理原有关联关系）
        checkGroupDao.deleteAssociation(checkGroup.getId());
// 3.调用DAO 在中间表中添加检查组中包含的检查项
        setCheckGroupAndCheckItem(checkGroup.getId(), checkItemIds);
    }


    /**
     * 查询所有检查组
     * @return 所有检查组数据
     */
    @Override
    public List<CheckGroup> findAll() {
// 1.调用DAO 查询所有检查组
        List<CheckGroup> checkGroups = checkGroupDao.findAll();
// 2.返回所有检查组
        return checkGroups;
    }





    }
