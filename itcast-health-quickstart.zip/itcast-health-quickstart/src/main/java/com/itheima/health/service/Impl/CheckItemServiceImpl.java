package com.itheima.health.service.Impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.health.dao.CheckItemDao;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.CheckItem;
import com.itheima.health.service.CheckItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CheckItemServiceImpl implements CheckItemService {

    @Autowired
    private CheckItemDao checkItemDao;
    @Override
    public void add(CheckItem checkItem) {
        checkItemDao.add(checkItem);
    }

    /**
     * 检查项分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    @Override
    public PageResult findPage(QueryPageBean queryPageBean) {
// 1.使用分页插件开始分页
        PageHelper.startPage(queryPageBean.getCurrentPage(),
                queryPageBean.getPageSize());
// 2.调用DAO分页查询
        Page<CheckItem> page =
                checkItemDao.findPage(queryPageBean.getQueryString());
        return new PageResult(page.getTotal(), page.getResult());
    }

    /**
     * 删除检查项
     * @param id 要删除的检查项id
     * @return 统一响应结果
     */
    @Override
    public boolean delete(Integer id) {
// 1.查询当前检查项是否和检查组关联
        long count = checkItemDao.findCountByCheckItemId(id);
// 2.如果当前检查项在检查组中不能删除, 返回false
        if (count > 0) {
            return false;
        }
// 3.检查项没有在检查组中,删除检查项
        checkItemDao.deleteById(id);
        return true;
    }

    @Override
    public CheckItem findById(Integer id) {
        CheckItem checkItem = checkItemDao.findById(id);
        return checkItem;
    }

    @Override
    public void edit(CheckItem checkItem) {
        checkItemDao.edit(checkItem);

    }

    @Override
    public List<CheckItem> findAll() {
        List<CheckItem> checkItems = checkItemDao.findAll();
        return checkItems;
    }



    }
