package com.itheima.health.service.Impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.health.dao.SetmealDao;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.Setmeal;
import com.itheima.health.service.SetmealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SetmealServiceImpl implements SetmealService {
    @Autowired
    private SetmealDao setmealDao;

    @Override
    public void add(Setmeal setmeal, Integer[] checkgroupIds) {
        // 1.调用DAO新增套餐
        setmealDao.add(setmeal);
// 2.调用DAO在中间表中添加套餐和检查组
        setSetmealAndCheckGroup(setmeal.getId(), checkgroupIds);


    }
    /**
     * 在中间表中添加套餐和检查组
     * @param setmealId 套餐id
     * @param checkgroupIds 套餐对应的所有检查组id
     */
    private void setSetmealAndCheckGroup(Integer setmealId, Integer[]
            checkgroupIds) {
        if (checkgroupIds != null && checkgroupIds.length > 0) {
            for (Integer checkgroupId : checkgroupIds) {
                Map<String, Integer> map = new HashMap<>();
                map.put("setmeal_id", setmealId);
                map.put("checkgroup_id", checkgroupId);
// 把套餐和对应的检查组保存到中间表
                setmealDao.setSetmealAndCheckGroup(map);
            }
        }
    }
    /**
     * 套餐分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    @Override
    public PageResult findPage(QueryPageBean queryPageBean) {
// 1.使用分页插件开始分页
        PageHelper.startPage(queryPageBean.getCurrentPage(),
                queryPageBean.getPageSize());
// 2.调用DAO分页查询
        Page<Setmeal> page = setmealDao.findPage(queryPageBean.getQueryString());
        return new PageResult(page.getTotal(), page.getResult());
    }


    /**
     * 根据id查询套餐信息
     * @param id 套餐id
     * @return 统一响应结果，只包含套餐信息
     */
    @Override
    public Setmeal findById(Integer id) {
// 1.调用DAO获取一条套餐信息，只包含套餐信息
        Setmeal setmeal = setmealDao.findById(id);
// 2.返回一条套餐信息，findById
        return setmeal;
    }
    /**
     * 根据套餐id查询对应的所有检查组id
     * @param setmealId 套餐id
     * @return 统一响应结果，套餐id对应的所有检查组id
     */
    @Override
    public List<Integer> findCheckGroupIdsBySetmealId(String setmealId) {
// 1.调用DAO根据套餐id查询对应的所有检查组id
        List<Integer> checkGroupIds =
                setmealDao.findCheckGroupIdsBySetmealId(setmealId);
// 2.返回套餐id对应的所有检查组id
        return checkGroupIds;
    }

    /**
     * 编辑套餐
     * @param setmeal 前端提交过来的套餐数据
     * @param checkgroupIds 套餐对应的检查组id
     */
    @Override
    public void edit(Setmeal setmeal, Integer[] checkgroupIds) {
// 1.调用DAO 编辑套餐
        setmealDao.edit(setmeal);
// 2.调用DAO 根据套餐id删除中间表数据（清理原有关联关系）
        setmealDao.deleteAssociation(setmeal.getId());
// 3.调用DAO 在中间表中添加检查组中包含的检查项
        setSetmealAndCheckgroup(setmeal.getId(), checkgroupIds);
    }
    // 在中间表中添加套餐中包含的检查组
    public void setSetmealAndCheckgroup(Integer setmealId, Integer[] checkgroupIds)
    {
        if (checkgroupIds != null && checkgroupIds.length > 0) {
            for (Integer checkgroupId : checkgroupIds) {
                Map<String, Integer> map = new HashMap<>();
                map.put("setmeal_id", setmealId);
                map.put("checkgroup_id", checkgroupId);
                setmealDao.setSetmealAndCheckgroup(map);
            }
        }
    }


}


