package com.itheima.health.service;

import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.Setmeal;

import java.util.List;

/**
 * 体检套餐业务层接口
 */
public interface SetmealService {
    /**
     * 新增套餐
     * @param setmeal 套餐数据
     * @param checkgroupIds 套餐包含的检查组
     */
    void add(Setmeal setmeal, Integer[] checkgroupIds);

    /**
     * 套餐分页查询
     * @param queryPageBean 前端提交过来的分页查询参数
     * @return 分页查询结果
     */
    PageResult findPage(QueryPageBean queryPageBean);


    /**
     * 根据id查询套餐信息
     * @param id 套餐id
     * @return 统一响应结果，只包含套餐信息
     */
    Setmeal findById(Integer id);
    /**
     * 根据套餐id查询对应的所有检查组id
     * @param setmealId 套餐id
     * @return 统一响应结果，套餐id对应的所有检查组id
     */
    List<Integer> findCheckGroupIdsBySetmealId(String setmealId);

    /**
     * 编辑套餐
     * @param setmeal 前端提交过来的套餐数据
     * @param checkgroupIds 套餐对应的检查组id
     */
    void edit(Setmeal setmeal, Integer[] checkgroupIds);


}

