package com.itheima.health;

import com.itheima.health.utils.QiniuUtils;
import org.junit.jupiter.api.Test;

public class QiniuUtilsTest {

    @Test
    public void testUpload() {
        QiniuUtils.upload2Qiniu("D:\\WeChat\\WeChat Files\\wxid_xj72euy208nu21\\FileStorage\\File\\2023-09\\QiniuUtilsTest.java","he");
    }
}
